package world;

public enum RoomTile {
	DIRTY, CLEAN, BLOCKED
}
