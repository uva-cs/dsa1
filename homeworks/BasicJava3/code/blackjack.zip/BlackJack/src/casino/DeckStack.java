package casino;

/**
 * A stack of more than one deck used in a casino game
 *
 */
public class DeckStack {
	
	public DeckStack(int numDecks) {
		
	}
	
	public Card dealTopCard() {
		return null;
	}
	
	protected void restoreDecks() {
		
	}
	
	public int cardsLeft() {
		return -1;
	}
	
	
}
